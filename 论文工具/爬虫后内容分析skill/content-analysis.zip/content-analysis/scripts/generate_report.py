#!/usr/bin/env python3
"""内容分析法 - 报告生成脚本

将结构化的分析内容生成格式化的 HTML 或 DOCX 报告。

输入JSON格式:
{
  "title": "报告标题",
  "author": "作者",
  "date": "2024-01-01",
  "sections": [
    {"level": 1, "title": "章节标题", "content": "<p>HTML内容</p>"}
  ]
}

用法示例:
  python scripts/generate_report.py --content report.json --format html --output report.html
  python scripts/generate_report.py --content report.json --format docx --output report.docx
"""

import argparse
import json
import os
import sys
from datetime import datetime

from jinja2 import Environment, FileSystemLoader


def generate_html_report(data, template_path, output_path):
    """使用 Jinja2 模板生成 HTML 报告。"""
    template_dir = os.path.dirname(os.path.abspath(template_path))
    template_name = os.path.basename(template_path)

    if not os.path.exists(template_path):
        raise FileNotFoundError(f"模板文件不存在: {template_path}")

    env = Environment(loader=FileSystemLoader(template_dir), autoescape=False)
    template = env.get_template(template_name)

    html_content = template.render(
        title=data.get("title", "内容分析报告"),
        author=data.get("author", ""),
        date=data.get("date", datetime.now().strftime("%Y-%m-%d")),
        sections=data.get("sections", [])
    )

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html_content)

    return output_path


def generate_docx_report(data, output_path):
    """使用 python-docx 生成 Word 报告。"""
    from docx import Document
    from docx.shared import Pt, RGBColor, Inches
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    doc = Document()

    # 设置默认字体
    style = doc.styles["Normal"]
    font = style.font
    font.name = "SimSun"
    font.size = Pt(12)

    # 封面标题
    title = doc.add_heading(data.get("title", "内容分析报告"), level=0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # 作者和日期
    if data.get("author"):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(f"作者：{data['author']}")
        run.font.size = Pt(14)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(f"日期：{data.get('date', datetime.now().strftime('%Y-%m-%d'))}")
    run.font.size = Pt(14)

    doc.add_page_break()

    # 目录占位
    doc.add_heading("目录", level=1)
    p = doc.add_paragraph("（请在Word中插入目录：引用 -> 目录 -> 自动目录）")
    p.runs[0].font.color.rgb = RGBColor(128, 128, 128)
    doc.add_page_break()

    # 遍历章节
    for section in data.get("sections", []):
        level = min(section.get("level", 1), 4)
        heading = section.get("title", "")

        if heading:
            doc.add_heading(heading, level=level)

        content = section.get("content", "")
        if content:
            _parse_content_to_docx(doc, content)

    doc.save(output_path)
    return output_path


def _parse_content_to_docx(doc, content):
    """将HTML内容解析并写入Word文档（支持基本段落、列表和表格）。"""
    lines = content.split("\n")
    table_buffer = []
    in_table = False

    for line in lines:
        stripped = line.strip()

        if not stripped:
            continue

        # 检测Markdown表格行
        if stripped.startswith("|") and stripped.endswith("|"):
            cells = [c.strip() for c in stripped.split("|")[1:-1]]
            # 跳过分隔行（如 |---|---|）
            if cells and all(set(c) <= set("-: ") for c in cells):
                continue
            table_buffer.append(cells)
            in_table = True
            continue
        elif in_table and table_buffer:
            # 表格结束，写入Word
            _write_table_to_docx(doc, table_buffer)
            table_buffer = []
            in_table = False

        # 标题
        if stripped.startswith("#### "):
            doc.add_heading(stripped[5:], level=4)
        elif stripped.startswith("### "):
            doc.add_heading(stripped[4:], level=3)
        elif stripped.startswith("## "):
            doc.add_heading(stripped[3:], level=2)
        # 列表项
        elif stripped.startswith("- ") or stripped.startswith("* "):
            doc.add_paragraph(stripped[2:], style="List Bullet")
        elif len(stripped) > 2 and stripped[0].isdigit() and stripped[1] == ".":
            doc.add_paragraph(stripped[2:].strip(), style="List Number")
        # 普通段落（去除HTML标签做简单处理）
        else:
            text = stripped
            # 简单去除常见HTML标签
            import re
            text = re.sub(r"<[^>]+>", "", text)
            if text:
                doc.add_paragraph(text)

    # 处理末尾的表格
    if table_buffer:
        _write_table_to_docx(doc, table_buffer)


def _write_table_to_docx(doc, table_data):
    """将表格数据写入Word文档。"""
    if not table_data:
        return

    from docx.shared import Pt

    num_cols = max(len(row) for row in table_data)
    table = doc.add_table(rows=len(table_data), cols=num_cols, style="Table Grid")

    for i, row in enumerate(table_data):
        for j, cell_text in enumerate(row):
            if j < num_cols:
                cell = table.cell(i, j)
                cell.text = cell_text
                # 表头加粗
                if i == 0:
                    for run in cell.paragraphs[0].runs:
                        run.bold = True

    doc.add_paragraph()  # 表格后空行


def main():
    parser = argparse.ArgumentParser(
        description="内容分析法 - 报告生成",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python scripts/generate_report.py --content report.json --format html --output report.html
  python scripts/generate_report.py --content report.json --format docx --output report.docx

输入JSON格式:
{
  "title": "报告标题",
  "author": "作者",
  "date": "2024-01-01",
  "sections": [
    {"level": 1, "title": "一、研究设计", "content": "<p>HTML内容</p>"},
    {"level": 2, "title": "1.1 研究问题", "content": "<table>...</table>"}
  ]
}
        """
    )
    parser.add_argument("--content", required=True, help="报告内容JSON文件路径")
    parser.add_argument("--format", required=True, choices=["html", "docx"],
                        help="输出格式: html 或 docx")
    parser.add_argument("--output", required=True, help="输出文件路径")
    parser.add_argument("--template", default="assets/report_template.html",
                        help="HTML模板文件路径(仅HTML格式时使用)")

    args = parser.parse_args()

    # 读取内容
    try:
        with open(args.content, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        print(json.dumps({"status": "error", "message": f"文件不存在: {args.content}"},
                         ensure_ascii=False))
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(json.dumps({"status": "error", "message": f"JSON解析错误: {str(e)}"},
                         ensure_ascii=False))
        sys.exit(1)

    # 验证数据结构
    if "sections" not in data:
        print(json.dumps({"status": "error", "message": "JSON数据缺少 'sections' 字段"},
                         ensure_ascii=False))
        sys.exit(1)

    try:
        if args.format == "html":
            # 解析模板路径（相对于脚本所在目录的上级）
            script_dir = os.path.dirname(os.path.abspath(__file__))
            template_path = os.path.normpath(os.path.join(script_dir, "..", args.template))
            output = generate_html_report(data, template_path, args.output)
        elif args.format == "docx":
            output = generate_docx_report(data, args.output)

        file_size = os.path.getsize(output)
        print(json.dumps({
            "status": "success",
            "output_file": os.path.abspath(output),
            "format": args.format,
            "file_size_bytes": file_size,
            "sections_count": len(data.get("sections", []))
        }, ensure_ascii=False))

    except Exception as e:
        print(json.dumps({"status": "error", "message": f"报告生成失败: {str(e)}"},
                         ensure_ascii=False))
        sys.exit(1)


if __name__ == "__main__":
    main()
