#!/usr/bin/env python3
"""内容分析法 - 数据统计分析脚本

对编码后的CSV数据进行描述统计、交叉分析、卡方检验和时间分布分析。

用法示例:
  python scripts/analyze_data.py --input data.csv --analysis descriptive --variables "来源,主题,情绪"
  python scripts/analyze_data.py --input data.csv --analysis cross-tab --var1 来源 --var2 情绪
  python scripts/analyze_data.py --input data.csv --analysis chi-square --var1 来源 --var2 情绪
  python scripts/analyze_data.py --input data.csv --analysis time --date-var 发布时间 --freq Y
  python scripts/analyze_data.py --input data.csv --analysis all --var1 来源 --var2 情绪 --date-var 发布时间
"""

import argparse
import json
import sys

import numpy as np
import pandas as pd
from scipy import stats


def descriptive_stats(df, variables=None):
    """计算描述统计：每个变量的频数和百分比。"""
    if variables is None:
        variables = df.columns.tolist()

    results = {}
    for var in variables:
        if var not in df.columns:
            continue
        series = df[var]
        counts = series.value_counts(dropna=False)
        total = len(df)
        valid_count = int(series.notna().sum())
        missing_count = int(series.isna().sum())

        categories = []
        for val, count in counts.items():
            if pd.isna(val):
                label = "NA(缺失)"
            else:
                label = str(val)
            categories.append({
                "value": label,
                "count": int(count),
                "percentage": round(count / total * 100, 2)
            })

        # 如果是数值型变量，补充基本统计量
        numeric_series = pd.to_numeric(series, errors="coerce")
        numeric_valid = numeric_series.notna().sum()
        extra = {}
        if numeric_valid > 0 and numeric_valid == valid_count:
            extra = {
                "mean": round(float(numeric_series.mean()), 4),
                "std": round(float(numeric_series.std()), 4),
                "min": round(float(numeric_series.min()), 4),
                "max": round(float(numeric_series.max()), 4),
                "median": round(float(numeric_series.median()), 4)
            }

        results[var] = {
            "total": total,
            "valid_count": valid_count,
            "missing_count": missing_count,
            "categories": categories,
            **extra
        }
    return results


def cross_tabulation(df, var1, var2):
    """生成交叉分析表（频数表 + 行百分比表）。"""
    if var1 not in df.columns or var2 not in df.columns:
        return {"error": f"变量不存在: {var1} 或 {var2}"}

    ct = pd.crosstab(df[var1], df[var2], margins=True, margins_name="合计")

    index_vals = [str(v) for v in ct.index.tolist()]
    col_vals = [str(v) for v in ct.columns.tolist()]

    counts_table = []
    for i, idx in enumerate(index_vals):
        row = [idx] + [int(v) for v in ct.iloc[i].tolist()]
        counts_table.append(row)

    # 行百分比（不含合计行）
    ct_pct = pd.crosstab(df[var1], df[var2], normalize="index").round(4) * 100
    pct_index = [str(v) for v in ct_pct.index.tolist()]
    pct_cols = [str(v) for v in ct_pct.columns.tolist()]
    pct_table = []
    for i, idx in enumerate(pct_index):
        row = [idx] + [round(float(v), 2) for v in ct_pct.iloc[i].tolist()]
        pct_table.append(row)

    return {
        "variable1": var1,
        "variable2": var2,
        "headers": [""] + col_vals,
        "counts": counts_table,
        "row_percentage_headers": [""] + pct_cols,
        "row_percentages": pct_table
    }


def chi_square_test(df, var1, var2):
    """执行卡方检验并计算 Cramer's V。"""
    if var1 not in df.columns or var2 not in df.columns:
        return {"error": f"变量不存在: {var1} 或 {var2}"}

    ct = pd.crosstab(df[var1], df[var2])

    if ct.size == 0 or ct.shape[0] < 2 or ct.shape[1] < 2:
        return {"error": "交叉表不足以执行卡方检验（至少需要2x2）"}

    chi2, p_value, dof, expected = stats.chi2_contingency(ct)

    min_expected = float(expected.min())
    n = int(ct.sum().sum())
    min_dim = min(ct.shape[0], ct.shape[1]) - 1
    cramers_v = float(np.sqrt(chi2 / (n * min_dim))) if min_dim > 0 and n > 0 else 0.0

    warnings = []
    if min_expected < 5:
        warnings.append("部分期望频数低于5，卡方检验结果可能不可靠，建议使用Fisher精确检验")
    if n < 40:
        warnings.append("总样本量低于40，建议谨慎解读结果")

    return {
        "variable1": var1,
        "variable2": var2,
        "chi_square": round(float(chi2), 4),
        "degrees_of_freedom": int(dof),
        "p_value": round(float(p_value), 6),
        "cramers_v": round(cramers_v, 4),
        "sample_size": n,
        "min_expected_frequency": round(min_expected, 2),
        "significant_at_005": bool(p_value < 0.05),
        "significant_at_001": bool(p_value < 0.01),
        "effect_size": "弱" if cramers_v < 0.1 else ("中等" if cramers_v < 0.3 else ("较强" if cramers_v < 0.5 else "强")),
        "warnings": warnings if warnings else None
    }


def time_distribution(df, date_var, freq="Y"):
    """计算时间分布：按年/季度/月统计样本数量。"""
    if date_var not in df.columns:
        return {"error": f"变量不存在: {date_var}"}

    df_copy = df.copy()
    df_copy[date_var] = pd.to_datetime(df_copy[date_var], errors="coerce")
    valid_mask = df_copy[date_var].notna()
    df_valid = df_copy[valid_mask].copy()
    invalid_count = int((~valid_mask).sum())

    if len(df_valid) == 0:
        return {"error": "日期变量无有效值"}

    freq_labels = {"Y": "年", "Q": "季度", "M": "月"}
    if freq == "Y":
        df_valid["period"] = df_valid[date_var].dt.year.astype(int)
    elif freq == "M":
        df_valid["period"] = df_valid[date_var].dt.to_period("M").astype(str)
    elif freq == "Q":
        df_valid["period"] = df_valid[date_var].dt.to_period("Q").astype(str)

    counts = df_valid["period"].value_counts().sort_index()
    distribution = []
    for period, count in counts.items():
        distribution.append({
            "period": str(period),
            "count": int(count)
        })

    return {
        "date_variable": date_var,
        "frequency": freq,
        "frequency_label": freq_labels.get(freq, freq),
        "distribution": distribution,
        "total_with_valid_dates": int(len(df_valid)),
        "invalid_date_count": invalid_count,
        "date_range": {
            "start": str(df_valid[date_var].min().date()),
            "end": str(df_valid[date_var].max().date())
        }
    }


def main():
    parser = argparse.ArgumentParser(
        description="内容分析法 - 数据统计分析",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python scripts/analyze_data.py --input data.csv --analysis descriptive --variables "来源,主题"
  python scripts/analyze_data.py --input data.csv --analysis cross-tab --var1 来源 --var2 情绪
  python scripts/analyze_data.py --input data.csv --analysis chi-square --var1 来源 --var2 情绪
  python scripts/analyze_data.py --input data.csv --analysis time --date-var 发布时间 --freq Y
  python scripts/analyze_data.py --input data.csv --analysis all --var1 来源 --var2 情绪 --date-var 发布时间
        """
    )
    parser.add_argument("--input", required=True, help="编码数据CSV文件路径")
    parser.add_argument("--analysis", required=True,
                        choices=["descriptive", "cross-tab", "chi-square", "time", "all"],
                        help="分析类型: descriptive=描述统计, cross-tab=交叉分析, chi-square=卡方检验, time=时间分布, all=全部")
    parser.add_argument("--variables", help="描述统计的变量列表(逗号分隔)")
    parser.add_argument("--var1", help="交叉分析/卡方检验的第一个变量")
    parser.add_argument("--var2", help="交叉分析/卡方检验的第二个变量")
    parser.add_argument("--date-var", help="时间分布分析的日期变量名")
    parser.add_argument("--freq", choices=["Y", "M", "Q"], default="Y",
                        help="时间分布频率: Y=按年, M=按月, Q=按季度")
    parser.add_argument("--output", help="输出JSON文件路径(默认输出到stdout)")

    args = parser.parse_args()

    # 读取数据
    try:
        df = pd.read_csv(args.input)
    except FileNotFoundError:
        print(json.dumps({"status": "error", "message": f"文件不存在: {args.input}"},
                         ensure_ascii=False))
        sys.exit(1)
    except Exception as e:
        print(json.dumps({"status": "error", "message": f"无法读取CSV文件: {str(e)}"},
                         ensure_ascii=False))
        sys.exit(1)

    result = {
        "status": "success",
        "input_file": args.input,
        "sample_size": len(df),
        "variables": list(df.columns),
        "analysis_type": args.analysis
    }

    # 描述统计
    if args.analysis in ("descriptive", "all"):
        variables = None
        if args.variables:
            variables = [v.strip() for v in args.variables.split(",")]
        result["descriptive"] = descriptive_stats(df, variables)

    # 交叉分析
    if args.analysis in ("cross-tab", "all"):
        if args.var1 and args.var2:
            result["cross_tab"] = cross_tabulation(df, args.var1, args.var2)
        elif args.analysis == "cross-tab":
            print(json.dumps({"status": "error", "message": "交叉分析需要 --var1 和 --var2 参数"},
                             ensure_ascii=False))
            sys.exit(1)

    # 卡方检验
    if args.analysis in ("chi-square", "all"):
        if args.var1 and args.var2:
            result["chi_square"] = chi_square_test(df, args.var1, args.var2)
        elif args.analysis == "chi-square":
            print(json.dumps({"status": "error", "message": "卡方检验需要 --var1 和 --var2 参数"},
                             ensure_ascii=False))
            sys.exit(1)

    # 时间分布
    if args.analysis in ("time", "all"):
        if args.date_var:
            result["time_distribution"] = time_distribution(df, args.date_var, args.freq)
        elif args.analysis == "time":
            print(json.dumps({"status": "error", "message": "时间分布分析需要 --date-var 参数"},
                             ensure_ascii=False))
            sys.exit(1)

    # 输出
    output_str = json.dumps(result, ensure_ascii=False, indent=2)

    if args.output:
        try:
            with open(args.output, "w", encoding="utf-8") as f:
                f.write(output_str)
            print(json.dumps({"status": "success", "output_file": args.output,
                              "sample_size": len(df)}, ensure_ascii=False))
        except Exception as e:
            print(json.dumps({"status": "error", "message": f"无法写入输出文件: {str(e)}"},
                             ensure_ascii=False))
            sys.exit(1)
    else:
        print(output_str)


if __name__ == "__main__":
    main()
