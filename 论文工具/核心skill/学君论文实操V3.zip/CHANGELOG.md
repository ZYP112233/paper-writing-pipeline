# 学君论文实操 V2.0 更新说明

**更新日期**：2026年6月30日
**版本号**：V2.0
**上一版本**：V1.0（8阶段 + 4审查者）

---

## 一、版本概述

V2.0 在 V1.0 的基础上新增两个核心环节（预提交审稿 + 投稿策略），系统从「8阶段 + 4审查者」扩展为「10环节 + 5审查者」，实现从选题到投稿的全流程闭环。

---

## 二、新增模块

### 2.1 预提交审稿人（peer-reviewer）

**路径**：`reviewers/peer-reviewer/SKILL.md`

**角色定位**：严厉的目标期刊匿名审稿人（Role P），以"寻找一切拒稿理由"为核心使命

**核心功能**：

| 维度 | 审查内容 | 评分权重 |
|------|----------|----------|
| 贡献价值 | 理论贡献是否实质性、知识增量是否可辨识 | 20分 |
| 文献对话 | 是否建立学术对话关系、有无"幽灵引用" | 15分 |
| 方法数据 | 方法适配性、数据可信度、操作化规范性 | 15分 |
| 创新性 | 是否真正提出新视角/新方法/新发现 | 20分 |
| 写作逻辑 | 论证链条完整性、跨章节一致性 | 15分 |
| 伦理规范 | 引用真实性、数据来源合法性 | 15分 |

**AI写作局限检测**（基于724篇AI一作论文实验数据）：

- 假引用检测（12.71% 的AI一作论文存在虚假引用）
- 主题聚焦度评估（73.8% 的AI论文主题不够聚焦）
- 文献综述深度检查（89.5% 的AI论文文献综述薄弱）
- 数据可信度审查（78.5% 的AI论文数据可靠性存疑）
- 创新性实质评估（83.7% 的AI论文创新性不足）
- 语言空洞度检测（67.9% 的AI论文存在空洞表达）

**输出物**：
- 百分制评分报告（≥80 通过 / 60-79 小修 / <60 大修 / <40 建议拒稿）
- 具体修改清单（逐条列出问题、位置、修改建议）
- 期刊适配评估（论文与目标期刊的匹配度分析）
- 修改模式建议（A 全文优化 / B 重点章节重写 / C 结构调整）

**交互设计**：审查报告输出后，主动征询用户是否根据审稿建议优化初稿

---

### 2.2 投稿策略阶段（submission-strategy）

**路径**：`stages/submission-strategy/SKILL.md`

**阶段定位**：格式化完成后的第10个环节，默认温度 0.5（策略思维与市场洞察）

**5步策略框架**：

| 步骤 | 内容 | 产出 |
|------|------|------|
| Step 1：PMF分析 | 产品-市场匹配度评估 | PMF匹配矩阵（6维度评分） |
| Step 2：期刊心理画像 | 将期刊视为"有心理特征的人"，分析偏好与需求 | 目标期刊画像卡 |
| Step 3：标题优化 | 确保标题具备"电梯演讲"效应 | 投稿版标题 |
| Step 4：时机与路径规划 | 一鱼多吃路径、并行投稿策略、投稿时机 | 投稿路线图 |
| Step 5：投稿后跟进 | 漏斗式拒稿应对、修改策略 | 应急方案 |

**10个实战技巧系统化整合**：

1. 先研究期刊再写论文 → 期刊心理画像
2. 从投稿思维转变成投喂思维 → 投喂策略分析
3. 基于PMF匹配思考 → PMF匹配矩阵（6维度）
4. 标题的"电梯演讲"效应 → 标题优化模块
5. 迭代思维与一鱼多吃 → 迭代路径设计（交作业→论坛→期刊→写书）
6. 主场期刊积累 → 期刊关系矩阵
7. 并行投稿策略 → 多论文在飞管理
8. 精准多投（非海投） → 目标期刊漏斗筛选
9. 编辑关系管理 → 从陌生人到熟人式投稿
10. 配额红利发现 → 征稿/组稿/专栏/特殊偏好情报

**内置工具**：
- PMF匹配矩阵（研究方向、方法论、创新层级、读者群体、发表周期、影响力匹配）
- 投稿信（Cover Letter）模板
- 漏斗式拒稿应对策略（拒稿→修改→转投的分级应对）
- 期刊"心理画像"分析框架

---

## 三、主 SKILL.md 集成变更

### 3.1 全局状态（Global State）

| 变更项 | 具体内容 |
|--------|----------|
| 新增阶段字段 | `submission_strategy`（含 journal_shortlist, pmf_score, cover_letter, submission_timeline） |
| 新增质量门 | `peer_review_passed`（通过条件：无严重期刊错配，创新性评分≥60） |

### 3.2 路由表

| 新增路由 | Skill 路径 | 触发关键词 | 前置条件 |
|----------|-----------|-----------|----------|
| 投稿策略 | `stages/submission-strategy/SKILL.md` | "投稿" "期刊选择" "投稿策略" "cover letter" "目标期刊" "PMF" "一鱼多吃" | formatting completed |
| 预提交审稿 | `reviewers/peer-reviewer/SKILL.md` | "审稿" "审稿人视角" "模拟审稿" "预提交审查" "审稿报告" | formatting completed（用户主动触发） |

### 3.3 温度梯度

| 新增阶段 | 默认温度 | 行为特征 |
|----------|----------|----------|
| 预提交审稿 (peer_review) | 0.1 | 冷酷无情，挑剔至极 |
| 投稿策略 (submission_strategy) | 0.5 | 策略思维与市场洞察 |

### 3.4 数据流转

```
格式化 → 预提交审稿：final_title, abstract, final_keywords, 全文内容
预提交审稿 → 投稿策略：review_report, revision_suggestions, journal_fit_assessment
投稿策略 → 全局更新：journal_shortlist, pmf_score, cover_letter, submission_timeline
```

### 3.5 审查剧场

| 变更项 | 具体内容 |
|--------|----------|
| 自动触发表 | 新增行：格式化完成后建议触发 peer-reviewer |
| 审查角色表 | 新增"预提交审稿人"角色 |
| 质量门标准 | 新增 peer_review_passed 的通过条件 |

### 3.6 协作协议

| 新增协作 | 场景 | 触发时机 |
|----------|------|----------|
| peer-reviewer | 投稿前模拟审稿 | 格式化完成后/用户主动触发 |
| submission-strategy | 制定投稿策略 | 预提交审稿后/用户主动触发 |

### 3.7 快速上手指南

- "系统覆盖的8个阶段" → 更新为"系统覆盖的10个环节"
- 新增"准备投稿"快速入口（"投稿策略" / "模拟审稿" / "目标期刊"）

---

## 四、文件结构变更

```
学君论文实操V2/
├── SKILL.md                          # 主调度中心（V2.0 更新）
├── CHANGELOG.md                       # 【新增】更新说明文件
├── 五源写作融合设计方案.md              # 历史设计文档
├── knowledge-base/
│   └── SKILL.md                       # 理论与方法资料库（60+理论、48方法）
├── references/
│   ├── mixed-methods/                 # 混合研究方法参考文献
│   ├── qualitative-methods/           # 质性研究方法参考文献
│   ├── quantitative-methods/          # 量化研究方法参考文献
│   └── speculative-methods/            # 思辨研究方法参考文献
├── reviewers/
│   ├── citation-checker/SKILL.md      # 引用核查者
│   ├── critical-reviewer/SKILL.md      # 批判审查者
│   ├── methodology-auditor/SKILL.md   # 方法审计者
│   ├── peer-reviewer/SKILL.md         # 【新增】预提交审稿人
│   └── style-editor/SKILL.md          # 文体编辑者
├── stages/
│   ├── topic-selection/SKILL.md       # 选题
│   ├── introduction/SKILL.md          # 前言
│   ├── literature-review/SKILL.md      # 文献综述
│   ├── theoretical-framework/SKILL.md # 理论框架
│   ├── methodology/SKILL.md           # 研究方法
│   ├── analysis/SKILL.md               # 分析论证
│   ├── conclusion/SKILL.md             # 结论讨论
│   ├── formatting/SKILL.md            # 格式化
│   └── submission-strategy/SKILL.md    # 【新增】投稿策略
└── templates/
    ├── quantitative-paper.md          # 量化研究论文模板
    ├── qualitative-paper.md           # 质性研究论文模板
    ├── mixed-paper.md                 # 混合研究论文模板
    └── speculative-paper.md           # 思辨研究论文模板
```

---

## 五、安装说明

### 5.1 全新安装

1. 将 `学君论文实操V2` 文件夹复制到 `.trae-cn/skills/` 目录下
2. 确保 `SKILL.md` 位于文件夹根目录
3. 文件夹结构保持不变（stages/、reviewers/ 等子目录完整）

### 5.2 从 V1.0 升级

1. 删除旧的 `学君论文实操` 文件夹（或重命名为 `学君论文实操V1_backup`）
2. 将 `学君论文实操V2` 重命名为 `学君论文实操` 并复制到 `.trae-cn/skills/` 目录
3. 或直接在 `学君论文实操V2` 中使用（name 字段已设为 "学君论文实操V2"）

### 5.3 注意事项

- V2.0 与 V1.0 的子 Skill 路径完全兼容，已有论文状态可无缝迁移
- 新增的 `submission_strategy` 阶段字段在已有状态中默认为 `locked`，不影响进行中的论文
- 新增的 `peer_review_passed` 质量门默认为 `false`，不影响已有质量门状态

---

## 六、V2.0.1 交互优化（2026年6月30日）

### 6.1 交互仪表盘

两个新增模块均加入**底部交互仪表盘**，每次回复后强制显示当前状态：

**预提交审稿仪表盘**：
- 论文标题、目标期刊、审稿进度（维度计数）
- 当前总分、审稿结论、质量门状态
- 修改项进度、当前温度
- NEXT操作提示（修改 / 重新审稿 / 投稿 / Export）

**投稿策略仪表盘**：
- 论文标题、目标期刊、PMF评分
- 当前步骤（Step 1-5）、投稿路径轮次
- 投稿信状态、质量门状态、当前温度
- NEXT操作提示（下一步 / 换期刊 / Export / 生成投稿信）

### 6.2 文档版本输出（Export）

两个模块均支持 `Export` 指令导出 HTML 文档：

| 模块 | 导出内容 | 文件名格式 |
|------|----------|-----------|
| 预提交审稿 | 完整审稿报告（含六维度评分、修改清单、期刊适配评估） | `审稿报告_[标题缩写]_[日期].html` |
| 投稿策略 | 完整投稿策略报告（含PMF评估、期刊画像、路径规划、投稿信、行动清单） | `投稿策略报告_[标题缩写]_[日期].html` |

**HTML报告特性**：
- 响应式布局，适配打印和屏幕阅读
- 彩色评级标签（Accept绿色 / Minor黄色 / Major红色 / Reject灰色）
- PMF评分可视化（高匹配绿色 / 中匹配黄色 / 低匹配红色）
- 表格化数据呈现，便于存档和分享

### 6.3 新增可用指令

| 指令 | 预提交审稿 | 投稿策略 |
|------|-----------|---------|
| Export | 导出审稿报告HTML | 导出策略报告HTML |
| 重新审稿 | 修改完成后再次审稿 | — |
| 投稿 | 进入投稿策略阶段 | — |
| 换期刊 | 重新评估期刊匹配 | 重新评估并更换目标期刊 |
| 改标题 | — | 重新进行标题优化 |
| 生成投稿信 | — | 单独生成/修改投稿信 |
| 上一步 | — | 返回上一策略步骤 |

---

---

## 八、V3.0 重大更新（2026年7月1日）

**更新日期**：2026年7月1日
**版本号**：V3.0
**上一版本**：V2.0.1（10环节 + 5审查者）

### 8.1 版本概述

V3.0 在 V2.0 的基础上新增两个核心能力：**量化数据分析引擎**（基于 statistical-analysis-advisor 融入）和**双信源文献真实性验证器**，系统从「10环节 + 5审查者」扩展为「12环节 + 6审查者」，实现从数据到文献到投稿的全链路质量保障。

### 8.2 新增模块

#### 8.2.1 量化数据分析阶段（data-analysis）

**路径**：`stages/data-analysis/SKILL.md`

**阶段定位**：研究方法阶段后的量化研究专属分析环节，默认温度 0.3（忠实于数据，克制解释）

**核心功能**：

| 功能模块 | 内容 | 产出 |
|----------|------|------|
| 数据质量诊断 | 缺失值、异常值、正态性、共同方法偏差 | 数据质量诊断报告 |
| 信效度检验 | Cronbach's α、CR、AVE、区分效度、重测信度 | 信效度检验表 |
| 统计检验选择 | T-test/ANOVA/Chi-square/Mann-Whitney/Kruskal-Wallis等决策树 | 检验推荐报告 |
| 假设检验执行 | 参数/非参数检验、调节/中介/SEM/HLM等高级方法 | 假设检验结果表 |
| 效应量与功效 | Cohen's d、η²、Cramér's V、事后功效、敏感性分析 | 效应量汇总+功效报告 |
| 结果整合 | 发现摘要、意外发现、稳健性检验、局限说明 | 结构化结果摘要 |

**内置 Python 脚本**：`scripts/main.py`（StatisticalAdvisor 类）
- `recommend_test()`: 基于数据特征推荐统计检验
- `check_assumptions()`: 正态性、方差齐性、样本量检查
- `calculate_power()`: 统计功效与样本量计算
- `get_effect_size_interpretation()`: 效应量解释

**参考文档**：
- `references/statistical_tests_guide.md`（检验选择详细指南）
- `references/assumption_tests.md`（假设检验前置条件）
- `references/power_analysis_guide.md`（功效分析与样本量）

**交互设计**：
- 底部仪表盘实时显示：样本概览、假设检验进度、统计质量指标
- `Export` 导出完整数据分析报告（Markdown/Word）
- 支持 `重新检验`、`效应量`、`功效分析`、`稳健性检验` 等指令

---

#### 8.2.2 文献真实性核实者（reference-verifier）

**路径**：`reviewers/reference-verifier/SKILL.md`

**角色定位**：双信源交叉验证专家，核心铁律——**单源验证不可接受，只有两独立信源一致才标记为"已验证"**

**信源分级**：

| 级别 | 信源类型 | 示例 |
|------|---------|------|
| 一级 | 综合学术数据库 | Google Scholar, Web of Science, Scopus, CNKI, Wanfang |
| 二级 | 出版商/官方平台 | Crossref, DOI.org, 出版社官网, ORCID |
| 三级 | 预印本/索引 | arXiv, SSRN, ResearchGate, Semantic Scholar |
| 四级 | 间接引用 | 其他论文引用列表、新闻报道（**不可作为独立验证源**） |

**验证状态判定**：

| 状态 | 条件 | 颜色 | 后续处理 |
|------|------|------|---------|
| VERIFIED | 两源均找到，所有必备字段一致 | 🟢 绿色 | 可放心引用 |
| CONFLICT | 两源均找到，但必备字段不一致 | 🔴 红色 | 必须人工核查 |
| PENDING | 仅一源找到 | 🟡 黄色 | 需补充第三信源 |
| UNVERIFIED | 两源均无记录 | 🔴 红色 | 高度怀疑虚假文献 |

**验证字段重要性**：
- **必备**：标题、作者、年份、期刊/出版社（任何一项不一致即 CONFLICT）
- **强烈建议**：DOI（不一致降级为 PENDING）
- **建议**：卷期页码（不一致记录但不影响状态）

**交互设计**：
- 底部仪表盘实时显示：验证进度条、状态分布、当前验证文献、风险指标
- `Export` 导出验证报告（Markdown/Word/CSV），含可信度评级 A/B/C/D/F
- 支持 `重新验证`、`只显示问题`、`修正` 等指令

---

### 8.3 主 SKILL.md 集成变更

#### 8.3.1 全局状态

| 变更项 | 具体内容 |
|--------|----------|
| 新增阶段字段 | `data_analysis`（含 statistical_results, assumption_checks, power_report） |
| 新增审查字段 | `reference_verification`（含 verified_count, conflict_count, unverified_count） |
| 新增质量门 | `reference_verification_passed`（通过条件：Verified>=90%，Conflict=0，Unverified=0） |

#### 8.3.2 路由表

| 新增路由 | Skill 路径 | 触发关键词 | 前置条件 |
|----------|-----------|-----------|----------|
| 量化分析 | `stages/data-analysis/SKILL.md` | "量化分析" "统计分析" "假设检验" "T检验" "方差分析" "回归" "SEM" "效应量" | methodology completed |
| 文献核实 | `reviewers/reference-verifier/SKILL.md` | "核查文献" "验证引用" "文献真实性" "双信源验证" | 文献综述/格式化后 |

#### 8.3.3 温度梯度

| 新增阶段 | 默认温度 | 行为特征 |
|----------|----------|----------|
| 量化分析 (data_analysis) | 0.3 | 忠实于数据，克制解释 |
| 文献核实 (reference_verification) | 0.1 | 冷酷核查，零容错 |

#### 8.3.4 数据流转

```
研究方法 → 量化分析：selected_method, sample_info, data_collection, hypotheses, operationalization
量化分析 → 结论讨论：findings_summary, statistical_results, assumption_checks, power_report
格式化 → 文献核实：final_title, 全文引用列表
文献核实 → 预提交审稿：verification_report, verified_references, conflict_references
```

#### 8.3.5 审查剧场

| 变更项 | 具体内容 |
|--------|----------|
| 自动触发表 | 新增行：格式化完成后建议触发 reference-verifier |
| 审查角色表 | 新增"文献核实者"角色（双信源验证、文献真实性、虚假引用检测） |
| 质量门标准 | 新增 reference_verification_passed（Verified>=90%，Conflict=0，Unverified=0） |

#### 8.3.6 反模式清单（新增）

- p值霸权：将p值作为唯一决策标准，不报告效应量和置信区间
- HARKing：事后构造假设并伪装成先验假设
- cherry-picking：选择性报告显著结果
- 过度拟合：中小样本运行过多变量
- 信效度跳过：不检验Cronbach's α就直接跑SEM

#### 8.3.7 快速上手指南

- "系统覆盖的10个环节" → 更新为"系统覆盖的12个环节"
- 新增"量化数据分析"快速入口
- 新增"核查文献真实性"快速入口

---

### 8.4 文件结构变更

```
学君论文实操V3/
├── SKILL.md                          # 主调度中心（V3.0 更新）
├── CHANGELOG.md                       # 更新说明文件
├── 五源写作融合设计方案.md              # 历史设计文档
├── knowledge-base/
│   └── SKILL.md                       # 理论与方法资料库
├── reviewers/
│   ├── citation-checker/SKILL.md      # 引用核查者
│   ├── critical-reviewer/SKILL.md      # 批判审查者
│   ├── methodology-auditor/SKILL.md   # 方法审计者
│   ├── peer-reviewer/SKILL.md         # 预提交审稿人
│   ├── reference-verifier/SKILL.md    # 【新增】文献真实性核实者
│   └── style-editor/SKILL.md          # 文体编辑者
├── stages/
│   ├── topic-selection/SKILL.md       # 选题
│   ├── introduction/SKILL.md          # 前言
│   ├── literature-review/SKILL.md      # 文献综述
│   ├── theoretical-framework/SKILL.md # 理论框架
│   ├── methodology/SKILL.md           # 研究方法
│   ├── data-analysis/SKILL.md          # 【新增】量化数据分析
│   │   ├── scripts/
│   │   │   └── main.py                 # 【新增】统计顾问Python脚本
│   │   └── references/
│   │       ├── statistical_tests_guide.md
│   │       ├── assumption_tests.md
│   │       └── power_analysis_guide.md
│   ├── analysis/SKILL.md               # 分析论证（质性）
│   ├── conclusion/SKILL.md             # 结论讨论
│   ├── formatting/SKILL.md            # 格式化
│   └── submission-strategy/SKILL.md    # 投稿策略
└── templates/
    ├── quantitative-paper.md          # 量化研究论文模板
    ├── qualitative-paper.md           # 质性研究论文模板
    ├── mixed-paper.md                 # 混合研究论文模板
    └── speculative-paper.md           # 思辨研究论文模板
```

---

### 8.5 安装说明

#### 8.5.1 全新安装

1. 将 `学君论文实操V3` 文件夹复制到 `.trae-cn/skills/` 目录下
2. 确保 `SKILL.md` 位于文件夹根目录
3. 文件夹结构保持不变（stages/、reviewers/ 等子目录完整）

#### 8.5.2 从 V2.0 升级

1. 删除旧的 `学君论文实操V2` 文件夹（或重命名为 `学君论文实操V2_backup`）
2. 将 `学君论文实操V3` 重命名为 `学君论文实操V3` 并复制到 `.trae-cn/skills/` 目录
3. 或直接在 `学君论文实操V3` 中使用（name 字段已设为 "学君论文实操V3"）

#### 8.5.3 注意事项

- V3.0 与 V2.0 的子 Skill 路径完全兼容，已有论文状态可无缝迁移
- 新增的 `data_analysis` 阶段字段在已有状态中默认为 `locked`
- 新增的 `reference_verification` 审查字段和质量门不影响已有状态
- 量化分析阶段的 Python 脚本需 Python 3.10+ 环境，依赖见 `requirements.txt`

---

## 九、已知限制

- 预提交审稿人的 AI 痕迹检测基于统计概率模型，不能100%替代人工审稿判断
- 投稿策略中的期刊"心理画像"需要用户主动提供目标期刊信息
- PMF匹配矩阵为辅助决策工具，最终投稿决策仍需用户综合判断
- 文献真实性验证依赖外部数据库的可访问性，部分数据库可能需要机构订阅
- 量化数据分析脚本的推荐结果需研究者最终确认，复杂模型（SEM/HLM）需人工判断
- 双信源验证对非常新的文献（<3个月）可能因索引延迟而标记为 pending
