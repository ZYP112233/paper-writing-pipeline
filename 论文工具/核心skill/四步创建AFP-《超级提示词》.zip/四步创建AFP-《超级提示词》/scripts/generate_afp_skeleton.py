#!/usr/bin/env python3
"""
AFP Prompt Skeleton Generator

Generate reusable Markdown skeletons for AFP Step 1, Step 2, Step 3, or Step 4 outputs.
This helper is intentionally dependency-free.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


STEP1 = """## 【{task_name}】核心工作流框架

### 阶段 1：{phase_1} (Diagnose)
- 目标：...
- 关键动作：...
- 判断点/分支：...

### 阶段 2：{phase_2} (Structure)
- 目标：...
- 关键动作：...
- 判断点/分支：...

### 阶段 3：{phase_3} (Validate)
- 目标：...
- 关键动作：...
- 判断点/分支：...

### 核心红线与边界
- ...

[TASK_COMPLETED]
"""

STEP2 = """# 提示词内容模块：{task_name}

## 一、场景常量（Constants）
- 领域与角色默认前提：...
- 必须遵守的规则 / 标准 / 边界：...
- 输出质量与风格硬约束：...

## 二、关键变量槽位（Variables）
| 变量 | 是否必填 | 影响范围 | 默认假设 |
|---|---|---|---|
| {{任务场景}} | 是 | 结构 / 路径 | 无 |
| {{目标与成功标准}} | 是 | 判断锚点 | 无 |
| {{受众与语境}} | 否 | 语气 / 粒度 | 面向普通专业用户 |
| {{材料与数据}} | 否 | 事实依据 | 无材料时仅做方法推导 |
| {{约束条件}} | 否 | 边界 / 禁止项 | 遵循通用安全与事实边界 |

## 三、算法步骤与 If-Then 决策（Logic）
### 3.1 步骤骨架（线性流程）
1) Step 1：...
   - 输入：...
   - 目标：...
   - 输出：...

2) Step 2：...
   - 输入：...
   - 目标：...
   - 输出：...

### 3.2 分支规则（If-Then）
- IF ... THEN ...
- IF 关键信息缺失 / 冲突 THEN 标记为「待确认」，不编造事实，以保守假设推进并说明。

### 3.3 判断锚点与收口逻辑
- 评估标准：...
- 风险触发条件：...
- 收口动作：...

## 四、编排结构说明
- 主要编排结构：...
- 编排方式与步骤对应关系：...
"""

STEP3 = """# {task_name} Auto-Flow Prompt v1.0

## 0. 推荐模型
- 推荐模型：...
- 使用场景：...
- 不适用场景：...

## 1. Runtime Protocol｜运行协议
1. 严格分阶段执行，不得跳步。
2. 每一阶段结束后输出 `[CHECKPOINT: 阶段名]` 并等待确认，除非用户明确要求一次性完成。
3. 缺少关键信息时最多询问 3 个问题；可安全默认时标明假设。
4. 不编造数据、来源、案例、引用。

## 2. System Kernel｜系统内核
- 角色：...
- Auto-Flow 模式：...
- 状态继承：每一阶段继承前序阶段产物，不重置假设。

## 3. Dual-Core Engine｜双核引擎
### Execution Core
...

### Quality-Control Core
- 检查变量完整性。
- 检查输出匹配阶段目标。
- 检查是否跳步或编造。

## 4. Execution Workflow｜执行工作流
### Phase 1：Diagnosis
- 输入：...
- 动作：...
- 输出：...
- 停机点：`[CHECKPOINT: Diagnosis]`

### Phase 2：Blueprint
- 输入：...
- 动作：...
- 输出：...
- 停机点：`[CHECKPOINT: Blueprint]`

### Phase 3：Execution
- 输入：...
- 动作：...
- 输出：...
- 停机点：`[CHECKPOINT: Execution]`

### Phase 4：Export
- 输入：...
- 动作：...
- 输出：...
- 停机点：`[TASK_COMPLETED]`

## 5. Compact HUD｜状态栏
```text
[HUD]
- 当前阶段：...
- 已完成：...
- 质检状态：...
- 下一步：...
```
"""

STEP4 = """## 1) 一眼结论（3行）
- 最致命结构问题：...
- 可能后果：...
- 优先修复：...

## 2) 风险热力榜（Top 5）
| 排名 | 问题 | 严重度 | 后果 | 优先修复位置 |
|---|---|---|---|---|
| 1 | ... | 高 | ... | ... |

## 3) 体检明细
### B1. Workflow Injection
#### 变量对照表
| 变量名 | 出现位置 | 是否定义 | 来源建议 | 风险等级 |
|---|---|---|---|---|

#### 阶段继承断点
| 断点 | 缺失声明 | 风险 | 修复建议 |
|---|---|---|---|

### B2. Role Calibration
| 冲突点 | 影响 | 一句话修复指令 |
|---|---|---|

### B3. Quality Kernel Sync
| 缺口 | 建议补丁 |
|---|---|

### B4. Step-by-Step & State
| 跳步风险点 | 原因 | 补丁 |
|---|---|---|

## 4) 补丁清单（可直接粘贴）
- Patch-1：...
- Patch-2：...
- Patch-3：...
- Patch-4：...
- Patch-5：...
"""

TEMPLATES = {
    "1": STEP1,
    "2": STEP2,
    "3": STEP3,
    "4": STEP4,
}


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate AFP output skeletons.")
    parser.add_argument("--step", choices=sorted(TEMPLATES), required=True, help="AFP step number: 1, 2, 3, or 4")
    parser.add_argument("--task-name", default="待命名任务", help="Task or prompt system name")
    parser.add_argument("--output", help="Optional output markdown path")
    args = parser.parse_args()

    text = TEMPLATES[args.step].format(
        task_name=args.task_name,
        phase_1="诊断与定界",
        phase_2="结构化建模",
        phase_3="校验与收口",
    )

    if args.output:
        output_path = Path(args.output)
        output_path.write_text(text, encoding="utf-8")
    else:
        sys.stdout.buffer.write(text.encode("utf-8"))
        sys.stdout.buffer.write(b"\n")


if __name__ == "__main__":
    main()
